<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Vite + Vue</title>
    <script type="module" crossorigin src="/assets/index-67q_HeRT.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/index-_iynunsI.css">
  </head>
  <body>
    <script src="src/cropper/cropper.js"></script>
    <div id="app"></div>

  </body>
</html>
<?php /**PATH /srv/users/hcmvkdmg/bcbpady-m1/resources/views/index.blade.php ENDPATH**/ ?>